//Abstraction
abstract class Atm {
	abstract void withdrawn();
	abstract void deposit();
	abstract void checkBalance();
	abstract void exit();	
}
