import java.util.*;
public class MainClass extends Atm//inheritance
{
	 static int w,b=50000,d;
	
	private int withdraw;//Encapsulation
	private int balance;
	private int deposit;
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	
	
	void withdrawn() {
		this.setBalance(50000);
		this.setWithdraw(w);
		if(this.getBalance()==0)
		{
			System.out.println("Zero balance");
		}
		else if(this.getWithdraw()>this.getBalance())
		{
			System.out.println("Balance is insufficient");
		}
		else
		{
			MainClass.b=this.getBalance()-this.getWithdraw();
		}
		System.out.println("Avalible balance= "+MainClass.b);
		System.out.println("Successfully "+this.getWithdraw()+" is withdrawed");
		}
	void deposit()
		{
		this.setBalance(50000);//polymorphsim
		this.setDeposit(d);
		MainClass.b=this.getBalance()+this.getDeposit();
		System.out.println("Avalible balance= "+MainClass.b);
		System.out.println("Successfully "+this.getDeposit()+" had deposited");
		}
	void checkBalance()
		{
		this.setBalance(50000);
		System.out.println("Avalible balance is: "+this.getBalance());
		}
	void exit()
	{System.out.println("EXIT");
	System.exit(0);
	}
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		MainClass mc= new MainClass();
		System.out.println("Automated Teller Machine");
        System.out.println("Choose 1 for Withdraw");
        System.out.println("Choose 2 for Deposit");
        System.out.println("Choose 3 for Check Balance");
        System.out.println("Choose 4 for EXIT");
        System.out.print("Choose the operation you want to perform:");
        int n = sc.nextInt();
        switch(n)
        {
        case 1:System.out.println("Enter the amount you want to withdraw");
        MainClass.w=sc.nextInt();
        	   mc.withdrawn();
        break;
        case 2:System.out.println("Enter the amount you want to diposit");
        	MainClass.d=sc.nextInt();
        	mc.deposit();
        break;
        case 3:mc.checkBalance();
        break;
        case 4:mc.exit();
        break;
        default:System.out.println("enter only 1, 2, 3 or 4 numbers");
        }
	}
}
/*
 OUTPUTS:
 
 CASE 1:
 Automated Teller Machine
Choose 1 for Withdraw
Choose 2 for Deposit
Choose 3 for Check Balance
Choose 4 for EXIT
Choose the operation you want to perform:1
Enter the amount you want to withdraw

300
Avalible balance= 49700
Successfully 300 is withdrawed

CASE 2:
Automated Teller Machine
Choose 1 for Withdraw
Choose 2 for Deposit
Choose 3 for Check Balance
Choose 4 for EXIT
Choose the operation you want to perform:2
Enter the amount you want to diposit
3000
Avalible balance= 53000
Successfully 3000 had deposited

CASE 3:
Automated Teller Machine
Choose 1 for Withdraw
Choose 2 for Deposit
Choose 3 for Check Balance
Choose 4 for EXIT
Choose the operation you want to perform:3
Avalible balance is: 50000

CASE 4:
Automated Teller Machine
Choose 1 for Withdraw
Choose 2 for Deposit
Choose 3 for Check Balance
Choose 4 for EXIT
Choose the operation you want to perform:4
EXIT



 
*/